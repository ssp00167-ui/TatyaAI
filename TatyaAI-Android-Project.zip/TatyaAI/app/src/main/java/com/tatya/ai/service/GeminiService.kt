package com.tatya.ai.service

import com.google.ai.client.generativeai.GenerativeModel

class GeminiService(private val apiKey: String) {
    private val model by lazy {
        GenerativeModel(
            modelName = "gemini-1.5-flash",
            apiKey = apiKey
        )
    }

    suspend fun generateResponse(prompt: String, language: String): String {
        return try {
            val systemInstruction = when (language) {
                "Marathi" -> "तुम्ही 'तात्या AI' (Tatya AI) आहात, एक अतिशय हुशार, आधुनिक आणि उपयुक्त असिस्टंट. उत्तरे नेहमी स्पष्ट आणि शुद्ध मराठीत द्या."
                "Hindi" -> "आप 'तात्या AI' (Tatya AI) हैं, एक आधुनिक, बुद्धिमान और सहायक AI साथी। हमेशा प्रामाणिक और सहज हिंदी में उत्तर दें।"
                else -> "You are 'Tatya AI', a sleek and hyper-intelligent futuristic AI assistant. Provide concise, clear, and insightful answers."
            }

            val finalPrompt = "$systemInstruction\n\nUser Question: $prompt"
            val response = model.generateContent(finalPrompt)
            response.text ?: "Tatya AI is unable to process this response."
        } catch (e: Exception) {
            "Connection Error: ${e.localizedMessage ?: "Unknown AI communication failure"}"
        }
    }
}
