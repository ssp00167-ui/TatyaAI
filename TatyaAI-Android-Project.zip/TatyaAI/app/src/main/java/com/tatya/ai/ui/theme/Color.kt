package com.tatya.ai.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF08090E)
val SurfaceDark = Color(0xFF10131E)
val CardBackground = Color(0xFF161B2B)

val ElectricBlue = Color(0xFF00F0FF)
val DeepCyan = Color(0xFF00A3FF)
val NeonPurple = Color(0xFF9D4EDD)
val GlowingMagenta = Color(0xFFE056FD)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val NeonGreen = Color(0xFF00FF88)
val NeonRed = Color(0xFFFF3366)
