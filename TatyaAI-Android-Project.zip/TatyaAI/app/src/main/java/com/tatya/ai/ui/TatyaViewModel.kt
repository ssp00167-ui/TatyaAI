package com.tatya.ai.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tatya.ai.data.ChatMessage
import com.tatya.ai.data.Note
import com.tatya.ai.data.TatyaDatabase
import com.tatya.ai.service.GeminiService
import com.tatya.ai.service.NetworkMonitor
import com.tatya.ai.service.VoiceEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class TatyaViewModel(application: Application) : AndroidViewModel(application) {
    private val db = TatyaDatabase.getDatabase(application).dao()
    private val networkMonitor = NetworkMonitor(application)

    val isOnline: StateFlow<Boolean> = networkMonitor.isOnline
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val messages: StateFlow<List<ChatMessage>> = db.getAllMessages()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notes: StateFlow<List<Note>> = db.getAllNotes()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedLanguage = MutableStateFlow("Marathi") // Marathi, Hindi, English
    val selectedLanguage: StateFlow<String> = _selectedLanguage.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _apiKey = MutableStateFlow("YOUR_GEMINI_API_KEY")
    val apiKey: StateFlow<String> = _apiKey.asStateFlow()

    private var geminiService = GeminiService(_apiKey.value)

    val voiceEngine = VoiceEngine(application) { recognizedText ->
        sendMessage(recognizedText)
    }

    fun setApiKey(key: String) {
        _apiKey.value = key
        geminiService = GeminiService(key)
    }

    fun setLanguage(lang: String) {
        _selectedLanguage.value = lang
        voiceEngine.setLanguage(lang)
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return
        viewModelScope.launch {
            db.insertMessage(ChatMessage(sender = "USER", content = text))

            if (!isOnline.value) {
                db.insertMessage(ChatMessage(
                    sender = "TATYA",
                    content = if (_selectedLanguage.value == "Marathi")
                        "आपण ऑफलाइन आहात. कृपया इंटरनेट कनेक्शन तपासा."
                    else if (_selectedLanguage.value == "Hindi")
                        "आप ऑफ़लाइन हैं। कृपया इंटरनेट कनेक्शन जांचें।"
                    else
                        "You are currently offline. Please reconnect to the internet."
                ))
                return@launch
            }

            _isGenerating.value = true
            val aiResponse = geminiService.generateResponse(text, _selectedLanguage.value)
            _isGenerating.value = false

            db.insertMessage(ChatMessage(sender = "TATYA", content = aiResponse))
            voiceEngine.speak(aiResponse)
        }
    }

    fun saveAsNote(title: String, content: String) {
        viewModelScope.launch {
            db.insertNote(Note(title = title, content = content))
        }
    }

    fun deleteNote(note: Note) {
        viewModelScope.launch {
            db.deleteNote(note)
        }
    }

    fun clearChat() {
        viewModelScope.launch {
            db.clearHistory()
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceEngine.shutdown()
    }
}
