package com.tatya.ai.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tatya.ai.ui.theme.*

@Composable
fun FuturisticGlowCard(
    modifier: Modifier = Modifier,
    borderColor: Color = ElectricBlue,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CardBackground)
            .border(
                1.dp,
                Brush.linearGradient(listOf(borderColor.copy(alpha = 0.8f), NeonPurple.copy(alpha = 0.2f))),
                RoundedCornerShape(16.dp)
            )
            .padding(14.dp),
        content = content
    )
}

@Composable
fun OnlineStatusBadge(isOnline: Boolean) {
    val statusColor = if (isOnline) NeonGreen else NeonRed
    val text = if (isOnline) "ONLINE" else "OFFLINE"

    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .clip(CircleShape)
            .background(SurfaceDark)
            .border(1.dp, statusColor.copy(alpha = 0.6f), CircleShape)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(statusColor)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = statusColor
        )
    }
}
