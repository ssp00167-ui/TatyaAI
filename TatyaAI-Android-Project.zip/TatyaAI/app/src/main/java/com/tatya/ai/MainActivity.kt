package com.tatya.ai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.navigation.compose.*
import com.tatya.ai.ui.TatyaViewModel
import com.tatya.ai.ui.screens.ChatScreen
import com.tatya.ai.ui.screens.NotesScreen
import com.tatya.ai.ui.screens.SettingsScreen
import com.tatya.ai.ui.theme.DarkBackground
import com.tatya.ai.ui.theme.ElectricBlue
import com.tatya.ai.ui.theme.TatyaAITheme

class MainActivity : ComponentActivity() {
    private val viewModel: TatyaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TatyaAITheme {
                val navController = rememberNavController()
                val items = listOf("Chat", "Notes", "Settings")
                var selectedItem by remember { mutableIntStateOf(0) }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    bottomBar = {
                        NavigationBar(containerColor = DarkBackground) {
                            items.forEachIndexed { index, screen ->
                                NavigationBarItem(
                                    icon = {
                                        when (screen) {
                                            "Chat" -> Icon(Icons.Default.Chat, contentDescription = null)
                                            "Notes" -> Icon(Icons.Default.Description, contentDescription = null)
                                            else -> Icon(Icons.Default.Settings, contentDescription = null)
                                        }
                                    },
                                    label = { Text(screen) },
                                    selected = selectedItem == index,
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = DarkBackground,
                                        selectedTextColor = ElectricBlue,
                                        indicatorColor = ElectricBlue,
                                        unselectedIconColor = Color.Gray,
                                        unselectedTextColor = Color.Gray
                                    ),
                                    onClick = {
                                        selectedItem = index
                                        navController.navigate(screen) {
                                            popUpTo(navController.graph.startDestinationId)
                                            launchSingleTop = true
                                        }
                                    }
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "Chat",
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(DarkBackground)
                    ) {
                        composable("Chat") { ChatScreen(viewModel) }
                        composable("Notes") { NotesScreen(viewModel) }
                        composable("Settings") { SettingsScreen(viewModel) }
                    }
                }
            }
        }
    }
}
