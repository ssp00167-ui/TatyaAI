package com.tatya.ai.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tatya.ai.ui.TatyaViewModel
import com.tatya.ai.ui.components.FuturisticGlowCard
import com.tatya.ai.ui.theme.*

@Composable
fun SettingsScreen(viewModel: TatyaViewModel) {
    val currentLang by viewModel.selectedLanguage.collectAsState()
    val apiKey by viewModel.apiKey.collectAsState()
    var tempKey by remember { mutableStateOf(apiKey) }
    val languages = listOf("Marathi", "Hindi", "English")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(
            text = "SYSTEM SETTINGS",
            color = ElectricBlue,
            fontSize = 20.sp,
            style = MaterialTheme.typography.titleLarge
        )

        // Language Select
        FuturisticGlowCard(borderColor = NeonPurple) {
            Text("AI Language Interface", color = GlowingMagenta, fontSize = 16.sp)
            Spacer(modifier = Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                languages.forEach { lang ->
                    val isSelected = currentLang == lang
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) ElectricBlue else SurfaceDark)
                            .border(
                                1.dp,
                                if (isSelected) ElectricBlue else TextSecondary.copy(alpha = 0.3f),
                                RoundedCornerShape(8.dp)
                            )
                            .clickable { viewModel.setLanguage(lang) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (lang == "Marathi") "मराठी" else if (lang == "Hindi") "हिंदी" else "English",
                            color = if (isSelected) DarkBackground else TextPrimary,
                            fontSize = 13.sp
                        )
                    }
                }
            }
        }

        // Gemini API Configuration
        FuturisticGlowCard(borderColor = ElectricBlue) {
            Text("Gemini API Key", color = ElectricBlue, fontSize = 16.sp)
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = tempKey,
                onValueChange = { tempKey = it },
                label = { Text("Paste Google AI Key", color = TextSecondary) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary
                ),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = { viewModel.setApiKey(tempKey) },
                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue),
                modifier = Modifier.align(Alignment.End)
            ) {
                Text("Save Key", color = DarkBackground)
            }
        }

        // Chat Data Management
        FuturisticGlowCard(borderColor = NeonRed) {
            Text("Memory & Cache", color = NeonRed, fontSize = 16.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = { viewModel.clearChat() },
                colors = ButtonDefaults.buttonColors(containerColor = NeonRed.copy(alpha = 0.8f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Purge Chat History", color = TextPrimary)
            }
        }
    }
}
