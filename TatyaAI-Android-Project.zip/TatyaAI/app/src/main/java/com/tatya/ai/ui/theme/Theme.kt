package com.tatya.ai.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val TatyaColorScheme = darkColorScheme(
    primary = ElectricBlue,
    secondary = NeonPurple,
    tertiary = GlowingMagenta,
    background = DarkBackground,
    surface = SurfaceDark,
    onPrimary = DarkBackground,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun TatyaAITheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = TatyaColorScheme,
        content = content
    )
}
