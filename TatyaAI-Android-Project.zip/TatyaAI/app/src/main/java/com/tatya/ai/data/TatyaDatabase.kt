package com.tatya.ai.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TatyaDao {
    @Query("SELECT * FROM chat_history ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ChatMessage>>

    @Insert
    suspend fun insertMessage(message: ChatMessage)

    @Query("DELETE FROM chat_history")
    suspend fun clearHistory()

    @Query("SELECT * FROM notes ORDER BY timestamp DESC")
    fun getAllNotes(): Flow<List<Note>>

    @Insert
    suspend fun insertNote(note: Note)

    @Delete
    suspend fun deleteNote(note: Note)
}

@Database(entities = [ChatMessage::class, Note::class], version = 1, exportSchema = false)
abstract class TatyaDatabase : RoomDatabase() {
    abstract fun dao(): TatyaDao

    companion object {
        @Volatile
        private var INSTANCE: TatyaDatabase? = null

        fun getDatabase(context: Context): TatyaDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    TatyaDatabase::class.java,
                    "tatya_ai_db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
