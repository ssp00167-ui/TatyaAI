package com.tatya.ai.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "chat_history")
data class ChatMessage(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sender: String, // "USER" or "TATYA"
    val content: String,
    val timestamp: Long = System.currentTimeMillis()
)
