# Tatya AI — Android starter project

This project was assembled from the Kotlin/Compose code in the user's Google AI Studio export.

## Included
- Kotlin + Jetpack Compose dark UI
- Marathi / Hindi / English language selection
- Gemini chat service (direct Google Generative AI SDK, as in the exported code)
- Android SpeechRecognizer and TextToSpeech
- Room database for chat history and notes
- Network status indicator
- Notes and Settings screens

## Important limitations before using
1. This is a starter project assembled from generated source, **not a verified production-ready app**. It has not been compiled or tested in this environment.
2. The export mentions Firebase AI Logic in its planning text, but the actual code uses the direct `com.google.ai.client.generativeai` SDK. Firebase AI Logic is not configured here.
3. The generated source uses the model name `gemini-1.5-flash` and SDK version `0.2.0`; availability/compatibility must be checked when building. If the model is retired or unavailable, update `GeminiService.kt` to a currently supported Gemini model and compatible SDK.
4. The API key is entered in Settings and held in app memory only. Do not publish an APK with a personal API key embedded or share the key publicly. A production app should call a secured backend / Firebase AI Logic rather than expose a key in the APK.
5. Offline mode supports local notes/history and an offline notice. Generative AI chat requires internet.

## Build APK from an Android phone using GitHub Actions (free tier limits apply)
1. Sign in to GitHub in Chrome and create a new **public** repository named `TatyaAI` (or a private repository if your account's Actions allowance supports it).
2. Download and extract this ZIP on your phone.
3. Upload the extracted project files and folders to the repository root. Keep `.github/workflows/build-apk.yml` in place. GitHub's mobile website may make folder uploads awkward; use GitHub's browser upload flow or the GitHub mobile app if available.
4. Open the repository → **Actions** → **Build Tatya AI APK** → **Run workflow**.
5. When the workflow completes successfully, open the run and download the `TatyaAI-debug-apk` artifact.
6. Extract the artifact ZIP and install `app-debug.apk`. Android may ask you to allow installation from that browser/file manager.

## Local build (if you later get access to a computer)
Open this folder in Android Studio, allow Gradle sync, then run the `app` configuration or use `gradle assembleDebug` with JDK 17 and Android SDK 34 installed.
